Welcome to Linux practice!

1. Let's see what is in our current directory
	$ ls

2. Let's go into the nested directory
	$ cd nested

3. Check what is in the current directory again. Remember the command?

4. Go into the directory that we see in the nested directory that is not rm_dir

5. Try to copy a file to the outer directory, linux_practice
	$ cp copy_me.txt ../..
	HINT: .. means previous directory, . means current directory!

6. Move a file to the outer directory, linux_practice
	$ mv move_me.txt BLANK
	HINT: What argument would we supply BLANK?

7. Remove the directory called trash
	$ rmdir trash
	HINT: The directory must be empty for this to work!

8. Go back a directory
	$ cd ..

9. Delete all the contents of rm_dir as well as the directory itself
	$ rm -rf rm_dir

10. Go back to the root directory of this zip
	$ cd ..

11. Find the flag in flag.txt. It wil start with FLAG.
	$ cat flag.txt
	HINT: This will output the file contents. It might be very long!
	      We can search for the FLAG by using grep. grep is a way to
              search file for contents. Try the following:

	$ cat flag.txt | grep -i FLAG
	HINT: cat outputs the file contents of flag.txt. The | means take the
              output of the last command and put it into the next command.
	      grep -i means search without case sensitivity, and FLAG is what
	      we are searching for. So all together, this command will look
              through the file for anything containing FLAG!
